package com.unext.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unext.model.DateInvalidException;
import com.unext.model.Ticket;
import com.unext.model.Train;
import com.unext.repository.TrainRepository;

@RestController
@RequestMapping("/ticket")
public class TicketController {
	@Autowired
	TrainRepository trainRepository;
	@RequestMapping("/bookticket")
	public String bookTicket(@RequestParam int code,int y,int m,int d,String name,int age,String gender) throws IOException, DateInvalidException {
		Optional<Train>trainData=trainRepository.findById(code);
		LocalDate date2=LocalDate.of(y, m, d);
		Train train=null;
		if(trainData.isPresent()) {
			train=trainData.get();
			Ticket ticket=new Ticket(train, date2);
			ticket.addPassanger(name, age, gender);	
			ticket.writeTicket();
			return "Booked Successfully!!";
		}	
		else {
			return "Failed to book ticket";
		}
	}
	@RequestMapping("/enquiry")
	public String enquiry(@RequestParam int code) {
		Optional<Train>trainData=trainRepository.findById(code);
		if(trainData.isPresent()) {
			return "Train is available";
		}
		return "Not Available";
	}
}

























/*
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unext.repository.TrainRepository;
import com.unext.model.*;


@RestController
@RequestMapping("/api")

class TicketController {
	@Autowired
	TrainRepository trainRepository;
	
	@RequestMapping("/Booking")
	public void bookTicket(@RequestParam int trainNo,@RequestParam String trainName,@RequestParam String str,@RequestParam String source,@RequestParam String destination, @RequestParam double ticketPrice ) {
		Optional<Train> train=trainRepository.findById(trainNo);
		if(enquiry(trainNo)=="Train is available") {
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("d/M/yyyy");
		    LocalDate travelDate = LocalDate.parse(str, dateFormat);
			Ticket t=new Ticket(train,travelDate);
			t.addPassanger(Name,Age,Gender);
			t.writeTicket();
			System.out.println("Ticket booked with PNR: " + t.getPnr());

		}
	}
	
	@RequestMapping("/en")
	public String enquiry(@RequestParam int trainNo) {
		Optional<Train> train=trainRepository.findById(trainNo);
		try {
			if(train.isPresent()==false) {
				throw new Nosuchtrai;
			}
		}catch() {
			
		}
	 return  "train available	";
	}
	
	
	@RequestMapping("/Available")
	public int numberOfTickets(@RequestParam String str) {
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("d/M/yyyy");
	    LocalDate travelDate = LocalDate.parse(str, dateFormat);
	    int count=Ticket.countTickets(travelDate);
	    return count;
	}
	
	@RequestMapping("/print")
	public String printTicket(@RequestParam String str) throws IOException {
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("d/M/yyyy");
	    LocalDate travelDate = LocalDate.parse(userInput, dateFormat);
	    return Ticket.printTicket( travelDate);
	}
	
}*/
