package com.unext.model;


public class DateInvalidException extends Exception {

	 public DateInvalidException(){
		super("Date is invalid");
	}

}

